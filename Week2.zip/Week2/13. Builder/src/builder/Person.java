package builder;
/**
 *
 * @author 984571
 */
public class Person {
	public String name;
	public String phoneNum;
	
	public Person(String name, String phoneNum){
		this.name = name;
		this.phoneNum = phoneNum;
	}
	
	public Person(String name){
		this.name = name;
	}
}

