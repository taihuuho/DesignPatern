package abstractfactory.models;
public class Micky extends Bag {

	public void setType(String type) {
		type ="Micky";
	}
	@Override
	public void setPrice(float price) {
		// TODO Auto-generated method stub
		
	}

	public float getPrice() {
		// TODO Auto-generated method stub
		return 0.25f;
	}

}
