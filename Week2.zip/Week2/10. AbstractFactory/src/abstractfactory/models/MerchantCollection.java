package abstractfactory.models;
public class MerchantCollection extends Bag {


	public void setType(String type) {
		type ="MerchantCollection";
	}

	public float getPrice() {
		// TODO Auto-generated method stub
		return 0.5f;
	}

	@Override
	public void setPrice(float price) {
		// TODO Auto-generated method stub
		
	}

	
}
