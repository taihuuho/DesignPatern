package abstractfactory.models;

public class ResuableShopper extends Bag {

	
	public void setType(String type){
		type ="ResuableShopper";
	}
	
	@Override
	public void setPrice(float price) {
		
	}
	public float getPrice() {
		// TODO Auto-generated method stub
		return 0.0f;
	}

}
