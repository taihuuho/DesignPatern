package abstractfactory.models;


public abstract class  Bag extends Package{

	public abstract void setPrice(float price);

}
