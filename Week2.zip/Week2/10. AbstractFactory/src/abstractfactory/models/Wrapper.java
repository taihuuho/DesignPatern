package abstractfactory.models;

import edu.mum.lsvs.entity.Package;

public abstract class Wrapper extends Package {
		
	public abstract void setPrice(float price);
}
