package abstractfactory.models;

public class EverydayValue extends Wrapper {
	@Override
	public void setPrice(float price) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setType(String type) {
         type = "EverydayValue";	
	}
	@Override
	public float getPrice() {
		// TODO Auto-generated method stub
		return 0.0f;
	}

}
