package edu.mum.lsvs;

public interface IFlyWeight {
    
        public void printCustomerInfo(int id, String name,String hospital,Image img);
}
